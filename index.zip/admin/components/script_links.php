<!-- Scripts -->
<script src="../src/jquery/jquery.js"></script>
<script src="../src/bootstrap/js/bootstrap.min.js"></script>
<script src="../src/fontawesome/js/all.min.js"></script>
<script src="../src/datatables/datatables.min.js"></script>

<script src="src/js/sidebar_header.js"></script>
<script src="src/js/custom_confirm.js"></script>