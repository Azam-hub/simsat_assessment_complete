<!-- CSS only -->
<link rel="stylesheet" href="../src/bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" href="../src/fontawesome/css/all.min.css">
<link rel="stylesheet" href="../src/fonts/fonts.css">
<link rel="stylesheet" href="../src/datatables/datatables.min.css">

<link rel="stylesheet" href="../src/css/_utils.css">
<link rel="stylesheet" href="src/css/_sidebar_header.css">

<link rel="shortcut icon" href="../src/img/favicon.png" type="image/x-icon">